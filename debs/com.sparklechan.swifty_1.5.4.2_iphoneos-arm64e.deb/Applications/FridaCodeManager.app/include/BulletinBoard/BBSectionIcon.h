#import <Foundation/NSObject.h>

@class BBSectionIconVariant;

@interface BBSectionIcon : NSObject

- (void)addVariant:(BBSectionIconVariant *)variant;

@end
