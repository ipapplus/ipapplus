#import <BaseBoard/BSProcessHandle.h>

@interface FBSProcessHandle : BSProcessHandle

@end
