#import "MPUMediaRemoteViewController.h"
#import "MPUControlCenterMediaControlsView.h"

@class MPUControlCenterMediaControlsView;

@interface MPUControlCenterMediaControlsViewController : MPUMediaRemoteViewController

@property (nonatomic, strong) MPUControlCenterMediaControlsView *view;

@end
