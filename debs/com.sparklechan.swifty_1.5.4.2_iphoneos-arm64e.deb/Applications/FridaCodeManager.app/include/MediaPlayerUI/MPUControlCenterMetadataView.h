#import "MPUNowPlayingMetadataView.h"

@interface MPUControlCenterMetadataView : MPUNowPlayingMetadataView

@end
