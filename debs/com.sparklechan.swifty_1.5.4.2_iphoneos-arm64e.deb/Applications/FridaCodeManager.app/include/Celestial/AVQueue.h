#import <Foundation/NSObject.h>

@interface AVQueue : NSObject

@end
