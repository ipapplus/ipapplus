#import <UIKit/UIKit.h>

API_AVAILABLE(ios(13.0))
@interface OBBaseWelcomeController : UIViewController

@property (assign, nonatomic) NSUInteger templateType;

@end
