#import <Foundation/Foundation.h>

@interface _NSConstantDictionary : NSDictionary

- (NSUInteger)capacity;

@end
