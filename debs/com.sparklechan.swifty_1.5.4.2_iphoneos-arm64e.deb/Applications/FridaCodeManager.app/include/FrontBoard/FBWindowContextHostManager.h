#import "FBSceneHostManager.h"

@interface FBWindowContextHostManager : FBSceneHostManager

@end
