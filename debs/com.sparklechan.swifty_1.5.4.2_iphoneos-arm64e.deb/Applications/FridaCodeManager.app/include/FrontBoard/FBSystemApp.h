#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *FBSystemAppBundleID();
