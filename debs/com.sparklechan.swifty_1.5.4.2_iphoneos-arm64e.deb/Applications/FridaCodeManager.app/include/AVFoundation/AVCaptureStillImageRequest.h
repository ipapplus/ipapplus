#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@interface AVCaptureStillImageRequest : NSObject

@property (assign) CGSize previewImageSize API_DEPRECATED("Removed in iOS 8", ios(5.0, 8.0));

@end
