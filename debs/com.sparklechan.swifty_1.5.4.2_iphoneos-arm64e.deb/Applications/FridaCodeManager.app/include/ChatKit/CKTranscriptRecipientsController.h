#import <UIKit/UITableViewController.h>

@class CKConversation;

@interface CKTranscriptRecipientsController : UITableViewController

@property (nonatomic, retain) CKConversation *conversation;

@end
