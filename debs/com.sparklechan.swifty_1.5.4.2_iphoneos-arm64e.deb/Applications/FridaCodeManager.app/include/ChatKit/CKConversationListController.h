#import <UIKit/UITableViewController.h>

@class CKConversationList;

@interface CKConversationListController : UITableViewController

@property (nonatomic, assign) CKConversationList *conversationList;

@end
