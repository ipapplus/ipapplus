#import <UIKit/UIView.h>

@class SBChevronView;

@interface SBLockScreenView : UIView

@property (nonatomic, retain) SBChevronView *topGrabberView;

@end
