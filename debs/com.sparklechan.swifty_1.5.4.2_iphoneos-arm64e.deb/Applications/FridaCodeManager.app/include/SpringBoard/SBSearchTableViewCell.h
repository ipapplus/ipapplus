#import <UIKit/UITableViewCell.h>

@interface SBSearchTableViewCell : UITableViewCell

@end
