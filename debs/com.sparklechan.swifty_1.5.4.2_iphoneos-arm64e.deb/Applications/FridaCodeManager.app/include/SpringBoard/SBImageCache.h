#import <Foundation/NSObject.h>

@interface SBImageCache : NSObject

@end
