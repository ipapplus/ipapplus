#import <Foundation/NSObject.h>

@class SBBulletinListSection;

@interface SBNotificationCenterSectionInfo : NSObject

@property (nonatomic, readonly) SBBulletinListSection *representedListSection;

@end
