#import <Foundation/NSObject.h>

@interface RecentCall : NSObject

- (int)type;

@end
