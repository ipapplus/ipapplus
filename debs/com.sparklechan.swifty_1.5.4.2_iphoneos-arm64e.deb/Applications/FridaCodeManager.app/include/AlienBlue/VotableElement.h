#import <Foundation/NSObject.h>

@interface VotableElement : NSObject

@end
