#import "PSListController.h"

@interface PSListItemsController : PSListController

@end
