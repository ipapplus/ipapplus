#import "PSSpecifier.h"

@interface NSArray (PreferencesAddition)

- (PSSpecifier *)specifierForID:(NSString *)ID;

@end
