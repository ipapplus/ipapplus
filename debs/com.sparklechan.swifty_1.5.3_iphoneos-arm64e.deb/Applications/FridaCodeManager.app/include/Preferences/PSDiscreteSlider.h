#import <UIKit/UIKit.h>

@interface PSDiscreteSlider : UISlider

@property (nonatomic, retain) UIColor *trackMarkersColor;

@end
