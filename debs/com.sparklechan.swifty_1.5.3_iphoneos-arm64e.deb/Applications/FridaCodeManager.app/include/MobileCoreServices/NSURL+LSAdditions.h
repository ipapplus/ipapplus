#import <Foundation/Foundation.h>

@interface NSURL (LSAdditions)

- (nullable NSURL *)fmfURL;
- (nullable NSURL *)fmipURL;
- (nullable NSURL *)mapsURL;
- (nullable NSURL *)photosURL;

@end
