#import "CNPredicate.h"

@interface CNEmailAddressContactPredicate : CNPredicate

@end
