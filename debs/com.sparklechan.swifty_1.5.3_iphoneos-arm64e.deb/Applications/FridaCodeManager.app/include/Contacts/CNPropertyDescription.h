#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface CNPropertyDescription : NSObject

@property (nonatomic, copy, readonly) NSString *key;

@end
