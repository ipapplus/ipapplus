#import <UIKit/UIViewController.h>

@interface MPUMediaRemoteViewController : UIViewController

@end
