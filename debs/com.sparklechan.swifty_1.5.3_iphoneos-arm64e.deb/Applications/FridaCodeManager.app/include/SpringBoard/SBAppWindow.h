#import <Foundation/NSObject.h>

@interface SBAppWindow : NSObject

@end
