#import <UIKit/UIView.h>

@interface SBIconContentView : UIView

@end
