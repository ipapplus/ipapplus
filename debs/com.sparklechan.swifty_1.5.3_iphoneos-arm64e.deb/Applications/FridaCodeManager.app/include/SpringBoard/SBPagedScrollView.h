#import <UIKit/UIKit.h>

@interface SBPagedScrollView : UIScrollView

@property (nonatomic, copy) NSArray *pageViews;

@end
