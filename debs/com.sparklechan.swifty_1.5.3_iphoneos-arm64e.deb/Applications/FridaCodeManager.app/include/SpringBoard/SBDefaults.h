#import <Foundation/Foundation.h>

@class SBExternalDefaults;

@interface SBDefaults : NSObject

+ (SBExternalDefaults *)externalDefaults;

@end