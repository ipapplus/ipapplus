#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface SBExternalCarrierDefaults : NSObject

@property (readonly, nonatomic) NSString *carrierName;

@end