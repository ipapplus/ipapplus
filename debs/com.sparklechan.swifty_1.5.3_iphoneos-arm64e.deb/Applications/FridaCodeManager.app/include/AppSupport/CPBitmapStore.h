#import <Foundation/NSObject.h>

@interface CPBitmapStore : NSObject

- (void)purge;

@end
