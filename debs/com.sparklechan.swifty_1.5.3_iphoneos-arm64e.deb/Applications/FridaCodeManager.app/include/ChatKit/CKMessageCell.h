#import <UIKit/UITableViewCell.h>

@interface CKMessageCell : UITableViewCell

@end
