#import "FigCaptureConnectionConfiguration.h"

API_AVAILABLE(ios(8.0))
@interface FigVideoCaptureConnectionConfiguration : FigCaptureConnectionConfiguration
@end
