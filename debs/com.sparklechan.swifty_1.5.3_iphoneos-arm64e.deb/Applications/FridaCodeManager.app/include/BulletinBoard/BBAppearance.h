#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface BBAppearance : NSObject

+ (instancetype)appearanceWithTitle:(NSString *)title;

@end
