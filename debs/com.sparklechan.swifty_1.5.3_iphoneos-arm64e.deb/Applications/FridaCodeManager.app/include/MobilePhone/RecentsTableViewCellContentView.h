#import <UIKit/UIView.h>

@interface RecentsTableViewCellContentView : UIView

@end
