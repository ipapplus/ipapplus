#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface TrackDescriptor : NSObject

@property (nonatomic, retain) NSString *songName;
@property (nonatomic, retain) NSString *artistName;

@end
